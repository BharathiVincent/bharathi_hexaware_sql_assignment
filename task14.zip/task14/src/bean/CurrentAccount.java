package bean;

public class CurrentAccount extends Account {
    private double overdraftLimit;

    public CurrentAccount(Customer customer, double overdraftLimit) {
        super("Current", 0.0, customer);
        this.overdraftLimit = overdraftLimit;
    }

    public double getOverdraftLimit() { return overdraftLimit; }
}

