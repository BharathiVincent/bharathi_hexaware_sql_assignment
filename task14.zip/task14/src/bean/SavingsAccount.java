package bean;

public class SavingsAccount extends Account {
    private double interestRate;
    private static final double MIN_BALANCE = 500.0;

    public SavingsAccount(Customer customer, double interestRate) {
        super("Savings", getMinBalance(), customer);
        this.interestRate = interestRate;
    }

    public double getInterestRate() {
        return interestRate;
    }

    @Override
    public void setAccountBalance(double accountBalance) {
        if (accountBalance >= getMinBalance()) {
            super.setAccountBalance(accountBalance);
        } else {
            throw new IllegalArgumentException("Minimum balance of " + getMinBalance() + " must be maintained.");
        }
    }

	public static double getMinBalance() {
		return MIN_BALANCE;
	}
}