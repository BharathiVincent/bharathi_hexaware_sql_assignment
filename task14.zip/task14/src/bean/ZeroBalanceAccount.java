package bean;

public class ZeroBalanceAccount extends Account {
	 public ZeroBalanceAccount(Customer customer) {
	        super("Zero Balance", 0.0, customer);
	    }

	    @Override
	    public void displayAccountInfo() {
	        super.displayAccountInfo();
	        System.out.println("This is a Zero Balance Account.");
	    }

}
