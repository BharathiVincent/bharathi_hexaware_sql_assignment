package service.impl;

import bean.Account;
import bean.Customer;
import bean.SavingsAccount;
import service.IBankServiceProvider;
import java.util.*;

public class BankServiceProviderImpl extends CustomerServiceProviderImpl implements IBankServiceProvider {
    private List<Account> accountsList = new ArrayList<>();
    private String branchName;
    private String branchAddress;

    public BankServiceProviderImpl(String branchName, String branchAddress) {
        this.branchName = branchName;
        this.branchAddress = branchAddress;
    }

    @Override
    public Account createAccount(Customer customer, long accNo, String accType, double balance) {
        Account account = new Account(accType, balance, customer);
        accountsList.add(account);
        registerAccount(account);
        return account;
    }

    @Override
    public List<Account> listAccounts() {
        return accountsList;
    }

    @Override
    public void calculateInterest() {
        for (Account account : accountsList) {
            if (account instanceof bean.SavingsAccount) {
                double interest = account.getAccountBalance() * ((SavingsAccount) account).getInterestRate() / 100;
                account.setAccountBalance(account.getAccountBalance() + interest);
            }
        }
    }
}
