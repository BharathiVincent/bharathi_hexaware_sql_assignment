package service.impl;

import bean.Account;
import bean.Transaction;
import service.ICustomerServiceProvider;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;

public class CustomerServiceProviderImpl implements ICustomerServiceProvider {
    private Map<Integer, Account> accountMap = new HashMap<>(); // Maps accountNumber to Account
    private Map<Long, List<Transaction>> transactionMap = new HashMap<>(); // Maps accountNumber to Transactions

    @Override
    public double getAccountBalance(long accountNumber) {
        Account account = accountMap.get(accountNumber);
        return account != null ? account.getAccountBalance() : 0.0;
    }

    @Override
    public double deposit(long accountNumber, double amount) {
        Account account = accountMap.get(accountNumber);
        if (account != null) {
            account.setAccountBalance(account.getAccountBalance() + amount);
            addTransaction(accountNumber, "Deposit", amount, Transaction.TransactionType.DEPOSIT);
            return account.getAccountBalance();
        }
        return 0.0;
    }

    @Override
    public double withdraw(long accountNumber, double amount) {
        Account account = accountMap.get(accountNumber);
        if (account == null) return 0.0;

        if (account instanceof bean.SavingsAccount) {
            double minBalance = bean.SavingsAccount.getMinBalance(); // Assuming MIN_BALANCE is public or accessible
            if (account.getAccountBalance() - amount >= minBalance) {
                account.setAccountBalance(account.getAccountBalance() - amount);
                addTransaction(accountNumber, "Withdraw", amount, Transaction.TransactionType.WITHDRAW);
                return account.getAccountBalance();
            }
        } else if (account instanceof bean.CurrentAccount) {
            double availableLimit = account.getAccountBalance() + ((bean.CurrentAccount) account).getOverdraftLimit();
            if (amount <= availableLimit) {
                account.setAccountBalance(account.getAccountBalance() - amount);
                addTransaction(accountNumber, "Withdraw", amount, Transaction.TransactionType.WITHDRAW);
                return account.getAccountBalance();
            }
        } else if (account instanceof bean.ZeroBalanceAccount) {
            if (amount <= account.getAccountBalance()) {
                account.setAccountBalance(account.getAccountBalance() - amount);
                addTransaction(accountNumber, "Withdraw", amount, Transaction.TransactionType.WITHDRAW);
                return account.getAccountBalance();
            }
        }

        return 0.0; // Insufficient balance or invalid account type
    }

    @Override
    public boolean transfer(long fromAccountNumber, long toAccountNumber, double amount) {
        Account fromAccount = accountMap.get(fromAccountNumber);
        Account toAccount = accountMap.get(toAccountNumber);

        if (fromAccount == null || toAccount == null) return false;

        double withdrawn = withdraw(fromAccountNumber, amount);
        if (withdrawn > 0) {
            deposit(toAccountNumber, amount);
            addTransaction(fromAccountNumber, "Transfer to " + toAccountNumber, amount, Transaction.TransactionType.TRANSFER);
            addTransaction(toAccountNumber, "Transfer from " + fromAccountNumber, amount, Transaction.TransactionType.DEPOSIT);
            return true;
        }

        return false;
    }

    @Override
    public Account getAccountDetails(long accountNumber) {
        return accountMap.get(accountNumber);
    }

    @Override
    public List<Transaction> getTransactions(long accountNumber, Date fromDate, Date toDate) {
        List<Transaction> transactions = transactionMap.getOrDefault(accountNumber, new ArrayList<>());
        List<Transaction> filteredTransactions = new ArrayList<>();

        for (Transaction transaction : transactions) {
            LocalDateTime transactionDate = transaction.getDate(); // Already LocalDateTime

            LocalDateTime fromDateTime = fromDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
            LocalDateTime toDateTime = toDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();

            if (!transactionDate.isBefore(fromDateTime) && !transactionDate.isAfter(toDateTime)) {
                filteredTransactions.add(transaction);
            }}
		return filteredTransactions;
        }

    // Helper method to add a transaction
    private void addTransaction(long accountNumber, String description, double amount, Transaction.TransactionType type) {
        Account account = accountMap.get(accountNumber);
        if (account != null) {
            Transaction transaction = new Transaction(account, description, type, amount);
            transactionMap.computeIfAbsent(accountNumber, k -> new ArrayList<>()).add(transaction);
        }
    }

    // Helper method to simulate account registration
    public void registerAccount(Account account) {
        accountMap.put(account.getAccountNumber(), account);
    }
}