package task9;
import java.util.Scanner;
public class Bank {
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        BankAccount account = null;
        System.out.println("Welcome to the Bank!");
        System.out.println("Choose account type:");
        System.out.println("1. Savings Account");
        System.out.println("2. Current Account");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();
        System.out.print("Enter Account Number: ");
        int accNo = scanner.nextInt();
        scanner.nextLine(); // consume newline
        System.out.print("Enter Customer Name: ");
        String name = scanner.nextLine();
        System.out.print("Enter Initial Balance: ");
        double balance = scanner.nextDouble();
        switch (choice) {
            case 1:
                System.out.print("Enter Interest Rate (%): ");
                double rate = scanner.nextDouble();
                account = new SavingsAccount(accNo, name, balance, rate);
                break;
            case 2:
                account = new CurrentAccount(accNo, name, balance);
                break;
            default:
                System.out.println("Invalid choice.");
                System.exit(0);
        }
        // Menu-driven interface
        int option;
        do {
            System.out.println("\n--- BANK MENU ---");
            System.out.println("1. Deposit");
            System.out.println("2. Withdraw");
            System.out.println("3. Calculate Interest");
            System.out.println("4. Check Balance");
            System.out.println("5. Account Details");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");
            option = scanner.nextInt();
            switch (option) {
                case 1:
                    System.out.print("Enter amount to deposit: ");
                    float dep = scanner.nextFloat();
                    account.deposit(dep);
                    break;
                case 2:
                    System.out.print("Enter amount to withdraw: ");
                    float wd = scanner.nextFloat();
                    account.withdraw(wd);
                    break;
                case 3:
                    account.calculateInterest();
                    break;
                case 4:
                    System.out.println("Current Balance: $" + account.getBalance());
                    break;
                case 5:
                    account.printAccountDetails();
                    break;
                case 6:
                    System.out.println("Thank you for banking with us!");
                    break;
                default:
                    System.out.println("Invalid option.");
            }
        } while (option != 6);
        scanner.close();
    }

}
