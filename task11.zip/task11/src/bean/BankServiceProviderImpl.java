package bean;
import service.IBankServiceProvider;
public class BankServiceProviderImpl extends CustomerServiceProviderImpl implements IBankServiceProvider{
	 private String branchName = "Main Branch";
	    private String branchAddress = "123 Main St";
	    @Override
	    public void createAccount(Customer customer, String accType, float balance) {
	        Account acc = null;
	        switch (accType.toLowerCase()) {
	            case "savings":
	                acc = new SavingsAccount(balance, customer, 0.04f);
	                break;
	            case "current":
	                acc = new CurrentAccount(balance, customer, 1000);
	                break;
	            case "zerobalance":
	                acc = new ZeroBalanceAccount(balance, customer);
	                break;
	            default:
	                System.out.println("Invalid account type.");
	                return;
	        }
	        accounts[count++] = acc;
	        System.out.println("Account created. Account Number: " + acc.getAccountNumber());
	    }
	    @Override
	    public void listAccounts() {
	        for (int i = 0; i < count; i++) {
	            System.out.println(accounts[i].getDetails());
	        }
	    }
	    @Override
	    public void calculateInterest() {
	        for (int i = 0; i < count; i++) {
	            if (accounts[i] instanceof SavingsAccount) {
	                SavingsAccount sa = (SavingsAccount) accounts[i];
	                float interest = sa.getBalance() * sa.getInterestRate();
	                sa.deposit(interest);
	                System.out.println("Interest of " + interest + " added to account " + sa.getAccountNumber());
	            }
	        }
	    }
	}

