package bean;
import service.ICustomerServiceProvider;
public class CustomerServiceProviderImpl implements ICustomerServiceProvider {
	protected Account[] accounts = new Account[100];
    protected int count = 0;
    protected Account findAccount(long accNo) {
        for (int i = 0; i < count; i++) {
            if (accounts[i].getAccountNumber() == accNo) return accounts[i];
        }
        return null;
    }
    @Override
    public float getAccountBalance(long accountNumber) {
        Account acc = findAccount(accountNumber);
        return (acc != null) ? acc.getBalance() : -1;
    }
    @Override
    public float deposit(long accountNumber, float amount) {
        Account acc = findAccount(accountNumber);
        if (acc != null) {
            acc.deposit(amount);
            return acc.getBalance();
        }
        return -1;
    }
    @Override
    public float withdraw(long accountNumber, float amount) {
        Account acc = findAccount(accountNumber);
        if (acc != null && acc.withdraw(amount)) return acc.getBalance();
        return -1;
    }
    @Override
    public boolean transfer(long fromAcc, long toAcc, float amount) {
        Account from = findAccount(fromAcc);
        Account to = findAccount(toAcc);
        if (from != null && to != null && from.withdraw(amount)) {
            to.deposit(amount);
            return true;
        }
        return false;
    }
    @Override
    public void getAccountDetails(long accountNumber) {
        Account acc = findAccount(accountNumber);
        if (acc != null) {
            System.out.println(acc.getDetails());
        } else {
            System.out.println("Account not found.");
        }
    }
}

