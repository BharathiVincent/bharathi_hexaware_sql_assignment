package app;
import java.util.Scanner;
import bean.*;
import service.*;
public class BankApp {
	public static void main(String[] args) {
        BankServiceProviderImpl bank = new BankServiceProviderImpl();
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("\n1. Create Account\n2. Deposit\n3. Withdraw\n4. Get Balance\n5. Transfer\n6. Get Account Details\n7. List Accounts\n8. Calculate Interest\n9. Exit");
            int choice = sc.nextInt();
            switch (choice) {
                case 1:
                    System.out.print("Enter Name: ");
                    String name = sc.next();
                    System.out.print("Email: ");
                    String email = sc.next();
                    System.out.print("Phone: ");
                    String phone = sc.next();
                    System.out.print("Account Type (savings/current/zerobalance): ");
                    String accType = sc.next();
                    System.out.print("Initial Balance: ");
                    float bal = sc.nextFloat();
                    bank.createAccount(new Customer(name, email, phone), accType, bal);
                    break;
                case 2:
                    System.out.print("Account No: ");
                    long accNoD = sc.nextLong();
                    System.out.print("Amount: ");
                    float amountD = sc.nextFloat();
                    float newBalD = bank.deposit(accNoD, amountD);
                    System.out.println(newBalD == -1 ? "Account not found" : "New Balance: " + newBalD);
                    break;
                case 3:
                    System.out.print("Account No: ");
                    long accNoW = sc.nextLong();
                    System.out.print("Amount: ");
                    float amountW = sc.nextFloat();
                    float newBalW = bank.withdraw(accNoW, amountW);
                    System.out.println(newBalW == -1 ? "Insufficient funds or Account not found" : "New Balance: " + newBalW);
                    break;
                case 4:
                    System.out.print("Account No: ");
                    long accNoB = sc.nextLong();
                    float balCheck = bank.getAccountBalance(accNoB);
                    System.out.println(balCheck == -1 ? "Account not found" : "Balance: " + balCheck);
                    break;
                case 5:
                    System.out.print("From Acc No: ");
                    long from = sc.nextLong();
                    System.out.print("To Acc No: ");
                    long to = sc.nextLong();
                    System.out.print("Amount: ");
                    float amt = sc.nextFloat();
                    System.out.println(bank.transfer(from, to, amt) ? "Transfer Successful" : "Transfer Failed");
                    break;
                case 6:
                    System.out.print("Account No: ");
                    long accDetail = sc.nextLong();
                    bank.getAccountDetails(accDetail);
                    break;
                case 7:
                    bank.listAccounts();
                    break;
                case 8:
                    bank.calculateInterest();
                    break;
                case 9:
                    System.out.println("Thank you!");
                    sc.close();
                    return;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
}


