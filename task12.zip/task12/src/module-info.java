/**
 * 
 */
/**
 * 
 */
module task12 {
}