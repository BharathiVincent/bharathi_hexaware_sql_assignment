package app;
import bean.*;
import java.util.*;
public class BankApp {
	 public static void main(String[] args) {
	        Scanner sc = new Scanner(System.in);
	        BankServiceProviderImpl bank = new BankServiceProviderImpl();
	        while (true) {
	            try {
	                System.out.println("\n1. Create Account 2. Deposit 3. Withdraw 4. Get Balance 5. Transfer 6. Get Account Details 7. List Accounts 8. Calculate Interest 9. Exit");
	                int ch = sc.nextInt();
	                switch (ch) {
	                    case 1:
	                        System.out.print("Name: ");
	                        String name = sc.next();
	                        System.out.print("Email: ");
	                        String email = sc.next();
	                        System.out.print("Type (Savings/Current/ZeroBalance): ");
	                        String type = sc.next();
	                        System.out.print("Initial Balance: ");
	                        float bal = sc.nextFloat();
	                        bank.create_account(new Customer(name, email), type, bal);
	                        break;
	                    case 2:
	                        System.out.print("Account No: ");
	                        long depAcc = sc.nextLong();
	                        System.out.print("Amount: ");
	                        float depAmt = sc.nextFloat();
	                        System.out.println("New Balance: " + bank.deposit(depAcc, depAmt));
	                        break;
	                    case 3:
	                        System.out.print("Account No: ");
	                        long wdAcc = sc.nextLong();
	                        System.out.print("Amount: ");
	                        float wdAmt = sc.nextFloat();
	                        System.out.println("New Balance: " + bank.withdraw(wdAcc, wdAmt));
	                        break;
	                    case 4:
	                        System.out.print("Account No: ");
	                        long balAcc = sc.nextLong();
	                        System.out.println("Balance: " + bank.get_account_balance(balAcc));
	                        break;
	                    case 5:
	                        System.out.print("From Account No: ");
	                        long from = sc.nextLong();
	                        System.out.print("To Account No: ");
	                        long to = sc.nextLong();
	                        System.out.print("Amount: ");
	                        float amt = sc.nextFloat();
	                        bank.transfer(from, to, amt);
	                        System.out.println("Transfer successful");
	                        break;
	                    case 6:
	                        System.out.print("Account No: ");
	                        long detailAcc = sc.nextLong();
	                        System.out.println(bank.getAccountDetails(detailAcc));
	                        break;
	                    case 7:
	                        bank.listAccounts();
	                        break;
	                    case 8:
	                        bank.calculateInterest();
	                        break;
	                    case 9:
	                        System.exit(0);
	                }
	            } catch (InvalidAccountException | InsufficientFundException | OverDraftLimitExcededException e) {
	                System.out.println("Error: " + e.getMessage());
	            } catch (NullPointerException e) {
	                System.out.println("Error: Null pointer encountered.");
	            } catch (Exception e) {
	                System.out.println("Unexpected error: " + e.getMessage());
	            }
	        }

	 }}
