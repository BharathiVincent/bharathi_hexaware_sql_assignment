package com.hexaware.hms.dao;
import com.hexaware.hms.exception.PatientNumberNotFoundException;
import com.hexaware.hms.entity.Appointment;
import com.hexaware.hms.util.DBConnUtil;
import com.hexaware.hms.util.DBPropertyUtil;
import java.sql.Connection;
import java.sql.*;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class HospitalServiceImpl implements IHospitalService {
	    private Connection conn;

	    public HospitalServiceImpl() {
	        this.conn = DBConnUtil.getDBConn();
	        if (this.conn == null) {
	            System.out.println("Failed to establish a database connection.");
	        }
	    }

	    @Override
	    public Appointment getAppointmentById(int appointmentId) {
	        if (conn == null) {
	            System.out.println("Database connection is not established. Cannot retrieve appointment.");
	            return null; // Exit the method if connection is null
	        }

	        Appointment appointment = null;
	        String query = "SELECT * FROM Appointment WHERE appointmentId = ?";

	        try (PreparedStatement preparedStatement = conn.prepareStatement(query)) {
	            preparedStatement.setInt(1, appointmentId);
	            ResultSet resultSet = preparedStatement.executeQuery();

	            if (resultSet.next()) {
	                appointment = new Appointment(
	                    resultSet.getInt("appointmentId"),
	                    resultSet.getInt("patientId"),
	                    resultSet.getInt("doctorId"),
	                    resultSet.getTimestamp("appointmentDate"),
	                    resultSet.getString("description")
	                );
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return appointment;
	    }

	    @Override
	    public List<Appointment> getAppointmentsForPatient (int patientId) throws PatientNumberNotFoundException {
	        if (conn == null) {
	            System.out.println("Database connection is not established. Cannot retrieve appointments.");
	            throw new PatientNumberNotFoundException("Database connection is not established.");
	        }

	        List<Appointment> appointments = new ArrayList<>();
	        String query = "SELECT * FROM Appointment WHERE patientId = ?";

	        try (PreparedStatement preparedStatement = conn.prepareStatement(query)) {
	            preparedStatement.setInt(1, patientId);
	            ResultSet resultSet = preparedStatement.executeQuery();

	            if (!resultSet.isBeforeFirst()) {
	                throw new PatientNumberNotFoundException("No appointments found for patient ID: " + patientId);
	            }

	            while (resultSet.next()) {
	                Appointment appointment = new Appointment(
	                    resultSet.getInt("appointmentId"),
	                    resultSet.getInt("patientId"),
	                    resultSet.getInt("doctorId"),
	                    resultSet.getTimestamp("appointmentDate"),
	                    resultSet.getString("description")
	                );
	                appointments.add(appointment);
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return appointments;
	    }

	    @Override
	    public List<Appointment> getAppointmentsForDoctor(int doctorId) {
	        if (conn == null) {
	            System.out.println("Database connection is not established. Cannot retrieve appointments.");
	            return new ArrayList<>(); // Return an empty list if connection is null
	        }

	        List<Appointment> appointments = new ArrayList<>();
	        String query = "SELECT * FROM Appointment WHERE doctorId = ?";

	        try (PreparedStatement preparedStatement = conn.prepareStatement(query)) {
	            preparedStatement.setInt(1, doctorId);
	            ResultSet resultSet = preparedStatement.executeQuery();

	            while (resultSet.next()) {
	                Appointment appointment = new Appointment(
	                    resultSet.getInt("appointmentId"),
	                    resultSet.getInt("patientId"),
	                    resultSet.getInt("doctorId"),
	                    resultSet.getTimestamp("appointmentDate"),
	                    resultSet.getString("description")
	                );
	                appointments.add(appointment);
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return appointments;
	    }

	    @Override
	    public boolean scheduleAppointment(Appointment appointment) {
	        if (conn == null) {
	            System.out.println("Database connection is not established. Cannot schedule appointment.");
	            return false; // Return false if connection is null
	        }

	        String query = "INSERT INTO Appointment (appointmentId, patientId,doctorId, appointmentDate, description) VALUES (?,?, ?, ?, ?)";

	        try (PreparedStatement preparedStatement = conn.prepareStatement(query)) {
	        	 preparedStatement.setInt(1, appointment.getAppointmentId());
	            preparedStatement.setInt(2, appointment.getPatientId());
	            preparedStatement.setInt(3, appointment.getDoctorId());
	            preparedStatement.setTimestamp(4, new Timestamp(appointment.getAppointmentDate().getTime()));
	            preparedStatement.setString(5, appointment.getDescription());

	            int rowsAffected = preparedStatement.executeUpdate();
	            return rowsAffected > 0; // Return true if the insertion was successful
	        } catch (SQLException e) {
	            e.printStackTrace();
	            return false; // Return false if there was an error
	        }
	    }

	    @Override
	    public boolean updateAppointment(Appointment appointment) {
	        if (conn == null) {
	            System.out.println("Database connection is not established. Cannot update appointment.");
	            return false; // Return false if connection is null
	        }

	        String query = "UPDATE Appointment SET appointmentId=?, patientId = ?, doctorId = ?, appointmentDate = ?, description = ? WHERE appointmentId = ?";

	        try (PreparedStatement preparedStatement = conn.prepareStatement(query)) {
	        	 preparedStatement.setInt(1, appointment.getAppointmentId());
	            preparedStatement.setInt(2, appointment.getPatientId());
	            preparedStatement.setInt(3, appointment.getDoctorId());
	            preparedStatement.setTimestamp(4, new Timestamp(appointment.getAppointmentDate().getTime()));
	            preparedStatement.setString(5, appointment.getDescription());
	            preparedStatement.setInt(6, appointment.getAppointmentId());

	            int rowsAffected = preparedStatement.executeUpdate();
	            return rowsAffected > 0; // Return true if the update was successful
	        } catch (SQLException e) {
	            e.printStackTrace();
	            return false; // Return false if there was an error
	        }
	    }

	    @Override
	    public boolean cancelAppointment(int appointmentId) {
	        if (conn == null) {
	            System.out.println("Database connection is not established. Cannot cancel appointment.");
	            return false; // Return false if connection is null
	        }

	        String query = "DELETE FROM Appointment WHERE appointmentId = ?";

	        try (PreparedStatement preparedStatement = conn.prepareStatement(query)) {
	            preparedStatement.setInt(1, appointmentId);
	            int rowsAffected = preparedStatement.executeUpdate();
	            return rowsAffected > 0; // Return true if the appointment was successfully deleted
	        } catch (SQLException e) {
	            e.printStackTrace();
	            return false; // Return false if there was an error
	        }
	    }
	}            