package com.hexaware.hms.presentation;

import com.hexaware.hms.dao.HospitalServiceImpl;
import com.hexaware.hms.entity.Appointment;
import com.hexaware.hms.exception.PatientNumberNotFoundException;

import java.util.Scanner;
import java.util.Date;

public class hospitalManagementSystem {
    public static void main(String[] args) throws PatientNumberNotFoundException {
        HospitalServiceImpl service = new HospitalServiceImpl();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n--- Hospital Management System ---");
            System.out.println("1. Get Appointment by ID");
            System.out.println("2. Get Patient Appointments");
            System.out.println("3. Schedule Appointment");
            System.out.println("4. Update Appointment");
            System.out.println("5. Cancel Appointment");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter appointment ID: ");
                    int appointmentId = scanner.nextInt();
                    System.out.println(service.getAppointmentById(appointmentId));
                    break;

                case 2:
                    System.out.print("Enter patient ID: ");
                    int patientId = scanner.nextInt();
                    System.out.println(service.getAppointmentsForPatient(patientId));
                    break;

                case 3:
                	System.out.print("Enter appointment ID: ");
                    int newappointmentId = scanner.nextInt();
                    System.out.print("Enter patient ID: ");
                    int newPatientId = scanner.nextInt();
                    System.out.print("Enter doctor ID: ");
                    int newDoctorId = scanner.nextInt();
                    scanner.nextLine(); // Consume newline

                    System.out.print("Enter appointment date (YYYY-MM-DD): ");
                    String dateInput = scanner.nextLine();
                    Date appointmentDate = java.sql.Date.valueOf(dateInput);

                    System.out.print("Enter description: ");
                    String description = scanner.nextLine();

                    Appointment newAppointment = new Appointment(0, newPatientId, newDoctorId, appointmentDate, description);
                    System.out.println(service.scheduleAppointment(newAppointment) ? "Appointment scheduled successfully!" : "Failed to schedule appointment.");
                    break;

                case 4:
                    System.out.print("Enter appointment ID to update: ");
                    int updateId = scanner.nextInt();
                    scanner.nextLine(); // Consume newline

                    System.out.print("Enter new appointment date (YYYY-MM-DD): ");
                    String newDateInput = scanner.nextLine();
                    Date newAppointmentDate = java.sql.Date.valueOf(newDateInput);

                    System.out.print("Enter new description: ");
                    String newDescription = scanner.nextLine();

                    Appointment updatedAppointment = new Appointment(updateId, 0, 0, newAppointmentDate, newDescription);
                    System.out.println(service.updateAppointment(updatedAppointment) ? "Appointment updated successfully!" : "Failed to update appointment.");
                    break;

                case 5:
                    System.out.print("Enter appointment ID to cancel: ");
                    int cancelId = scanner.nextInt();
                    System.out.println(service.cancelAppointment(cancelId) ? "Appointment canceled successfully!" : "Failed to cancel appointment.");
                    break;

                case 6:
                    System.out.println("Exiting system... Thank you!");
                    scanner.close();
                    System.exit(0);
                    break;

                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }
        }
    }
}